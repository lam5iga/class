﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Knite
{
    public class knite
    { 
        public float maxHP = 500; //макс ОЗ
        public float MxDmg = 100; //макс урон
        float currentHP = 500;
        float MDmg;
        bool art = false;
        Random rnd = new Random();

        public float HP()
        {
            currentHP = currentHP - Attack();
            return currentHP;
        }
        public void TakeOnOff()
        {
            if (art == false)
            {
                art = true;
            }
            else
            {
                art = false;
            }
        }
        public void MaxDamage()
        {
            if (art == true)
            {
                MDmg = (float)(MxDmg + MxDmg * 0.5);
            }
        }
        public float Attack() //метод для атаки
        {
            float dmg = rnd.Next(0, (int)MDmg);
            return dmg;
        }
    }
}
