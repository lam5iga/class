﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Knite
{
    public class knite
    { 
        public static float maxHP = 500; //макс ОЗ
        public static float MxDmg = 100; //макс урон
        static float currentHP = 500;
        static float MDmg = MxDmg;
        static bool art = false;
        static Random rnd = new Random();

        public static float HP()
        {
            currentHP = currentHP - Attack();
            return currentHP;
        }
        public static void TakeOnOff()
        {
            if (art == false)
            {
                art = true;
            }
            else
            {
                art = false;
            }
        }
        public static void MaxDamage()
        {
            if (art == true)
            {
                MDmg = (float)(MxDmg + MxDmg * 0.5);
            }
        }
        public static float Attack() //метод для атаки
        {
            float dmg = rnd.Next(0, (int)MDmg);
            return dmg;
        }
    }
}
